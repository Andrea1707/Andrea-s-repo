/**
 * Lab6Esercizio3
 */
public class Lab6Esercizio3 {

    public static void main(String[] args) {
        System.out.print( Matrix.ToString (Matrix.RandomMatrix(5, 5, 10)));
        
    }
}