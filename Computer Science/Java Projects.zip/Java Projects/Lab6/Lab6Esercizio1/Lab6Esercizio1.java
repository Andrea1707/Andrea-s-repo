/**
 * Lab6Esercizio1
 */
public class Lab6Esercizio1 {

    public static void main(String[] args) {

    int [][] matrix = Matrix.RandomMatrix(2, 5, 10);
    System.out.print( Matrix.ToString (matrix));

    System.out.print(Matrix.MatrixInfo(matrix));
        

    }
} 